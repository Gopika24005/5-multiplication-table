import java.util.*;
class Main
{
	public static void main(String[] args) 
	{
		int n=1;
	    for(int i=10;i>=n;i--)
	    {
	        int sum=i*5;
	        System.out.println(sum );
	        
	    }
	}
}